package com.example.projectbp2711

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class activity_about : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about)
    }
}